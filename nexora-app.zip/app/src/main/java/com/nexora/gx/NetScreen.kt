package com.nexora.gx

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.max

class Hst(val n: String, val h: String)
class DnsP(val n: String, val ip: String, val host: String)
class Stats(val avg: Int, val jit: Int, val loss: Int)

val HOSTS = listOf(Hst("Cloudflare", "1.1.1.1"), Hst("Google", "8.8.8.8"), Hst("Quad9", "9.9.9.9"))
val DNSS = listOf(DnsP("Cloudflare", "1.1.1.1", "one.one.one.one"), DnsP("Google", "8.8.8.8", "dns.google"),
    DnsP("Quad9", "9.9.9.9", "dns.quad9.net"), DnsP("AdGuard", "94.140.14.14", "dns.adguard-dns.com"))
const val QUIET = "settings put global wifi_scan_always_enabled 0; settings put global ble_scan_always_enabled 0"

fun tcpMs(h: String, p: Int): Long = try {
    val t = System.nanoTime()
    Socket().use { it.connect(InetSocketAddress(h, p), 1500) }
    (System.nanoTime() - t) / 1_000_000
} catch (e: Throwable) { -1L }

fun dnsMs(ip: String): Long = try {
    val q = ByteArrayOutputStream(); val o = DataOutputStream(q)
    o.writeShort(0x1234); o.writeShort(0x0100); o.writeShort(1); o.writeShort(0); o.writeShort(0); o.writeShort(0)
    for (l in "google.com".split(".")) { o.writeByte(l.length); o.writeBytes(l) }
    o.writeByte(0); o.writeShort(1); o.writeShort(1)
    val b = q.toByteArray()
    DatagramSocket().use { s ->
        s.soTimeout = 1500
        val t = System.nanoTime()
        s.send(DatagramPacket(b, b.size, InetAddress.getByName(ip), 53))
        val r = ByteArray(512); s.receive(DatagramPacket(r, r.size))
        (System.nanoTime() - t) / 1_000_000
    }
} catch (e: Throwable) { -1L }

fun stats(xs: List<Long>): Stats {
    val ok = xs.filter { it >= 0 }
    if (xs.isEmpty()) return Stats(0, 0, 0)
    if (ok.isEmpty()) return Stats(0, 0, 100)
    val j = if (ok.size > 1) ok.zipWithNext { a, b -> abs(a - b) }.average().toInt() else 0
    return Stats(ok.average().toInt(), j, 100 * (xs.size - ok.size) / xs.size)
}

@Composable
fun NetScreen(st: Int, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val samples = remember { mutableStateListOf<Long>() }
    val dns = remember { mutableStateMapOf<String, Long>() }
    var running by remember { mutableStateOf(true) }
    var hi by remember { mutableIntStateOf(0) }
    var custom by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("> pronto") }
    val c = custom.trim()
    val (th, tp) = if (c.isNotEmpty()) c.substringBefore(":") to (c.substringAfter(":", "443").toIntOrNull() ?: 443) else HOSTS[hi].h to 443
    LaunchedEffect(th, tp) { samples.clear() }
    LaunchedEffect(running, th, tp) {
        while (running) {
            val ms = withContext(Dispatchers.IO) { tcpMs(th, tp) }
            samples.add(ms); if (samples.size > 40) samples.removeAt(0)
            delay(700)
        }
    }
    val s = stats(samples.toList())
    val last = samples.lastOrNull() ?: -1L
    val (ql, qc) = when {
        samples.isEmpty() -> "AGUARDANDO" to GR
        s.loss > 10 || s.avg > 150 -> "RUIM" to Color(0xFFFF5470)
        s.avg > 80 -> "MEDIO" to Color(0xFFFFC857)
        s.avg > 40 -> "BOM" to CY
        else -> "EXCELENTE" to OK
    }
    fun needSh(): Boolean { if (st == 2) return false; log = "> ative e autorize o Shizuku na tela principal"; return true }
    suspend fun bench(): DnsP? {
        dns.clear()
        for (p in DNSS) dns[p.n] = withContext(Dispatchers.IO) { listOf(dnsMs(p.ip), dnsMs(p.ip)).filter { it >= 0 }.minOrNull() ?: -1L }
        return DNSS.filter { (dns[it.n] ?: -1L) >= 0 }.minByOrNull { dns[it.n]!! }
    }
    suspend fun apply(b: DnsP): String = withContext(Dispatchers.IO) { sh("settings put global private_dns_mode hostname; settings put global private_dns_specifier ${b.host}") }
    fun job(needs: Boolean, f: suspend () -> Unit) { if (busy || (needs && needSh())) return; scope.launch { busy = true; f(); busy = false } }
    fun turbo() = job(true) {
        log = "> TURBO: limpando RAM..."; withContext(Dispatchers.IO) { sh("am kill-all") }
        log = "> TURBO: reduzindo picos de ping..."; withContext(Dispatchers.IO) { sh(QUIET) }
        log = "> TURBO: escolhendo DNS..."; val b = bench()
        if (b != null) apply(b)
        running = true; log = "> TURBO concluido. DNS: ${b?.n ?: "sem resposta"}"
    }
    Row(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1233), BG, BG))).padding(24.dp, 14.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Chip("< VOLTAR", false) { onBack() }
                Spacer(Modifier.width(12.dp))
                Text("ANTI-LAG", fontSize = 22.sp, fontWeight = FontWeight.Black, color = CY, letterSpacing = 3.sp)
            }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CARD).border(1.dp, qc.copy(alpha = 0.6f), RoundedCornerShape(20.dp)).padding(16.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(if (last >= 0) "$last" else "--", color = Color.White, fontSize = 60.sp, fontWeight = FontWeight.Black)
                    Text(" ms", color = GR, fontSize = 18.sp, modifier = Modifier.padding(bottom = 10.dp))
                    Spacer(Modifier.weight(1f))
                    Text(ql, color = qc, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp)
                }
                Canvas(Modifier.fillMaxWidth().height(100.dp)) {
                    val mx = max(100f, (samples.maxOrNull() ?: 0L).toFloat() * 1.2f)
                    val dx = size.width / 39f
                    val path = Path()
                    samples.forEachIndexed { i, v ->
                        val y = if (v < 0) size.height else size.height - (v / mx) * size.height
                        if (i == 0) path.moveTo(0f, y) else path.lineTo(i * dx, y)
                    }
                    drawPath(path, CY, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("MEDIA", "${s.avg} ms", Modifier.weight(1f))
                Stat("JITTER", "${s.jit} ms", Modifier.weight(1f))
                Stat("PERDA", "${s.loss}%", Modifier.weight(1f))
            }
            Text("Mede a qualidade da sua conexao ate o servidor escolhido. Para o servidor do jogo, use o IP e uma porta TCP dele.", color = GR, fontSize = 11.sp)
        }
        LazyColumn(Modifier.weight(1f).fillMaxHeight(), contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(Brush.horizontalGradient(listOf(CY, VI)))
                    .clickable { turbo() }, contentAlignment = Alignment.Center) {
                    Text(if (busy) "TRABALHANDO..." else "ANTI-LAG TURBO", color = BG, fontWeight = FontWeight.Black, fontSize = 14.sp, letterSpacing = 3.sp)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF060A14)).border(1.dp, EDGE, RoundedCornerShape(16.dp)).padding(12.dp)) {
                    Text("CONSOLE", color = GR, fontSize = 10.sp, letterSpacing = 3.sp)
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp), color = CY, trackColor = EDGE)
                    Text(log, color = OK, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
            item { Label("MONITOR DE PING") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip(if (running) "PAUSAR" else "INICIAR", running) { running = !running }
                    HOSTS.forEachIndexed { i, h -> Chip(h.n, custom.isEmpty() && hi == i) { custom = ""; hi = i } }
                }
            }
            item {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CARD).border(1.dp, EDGE, RoundedCornerShape(14.dp)).padding(14.dp, 12.dp)) {
                    if (custom.isEmpty()) Text("Servidor do jogo (ip ou host:porta)", color = GR, fontSize = 13.sp)
                    BasicTextField(custom, { custom = it }, textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                        cursorBrush = SolidColor(CY), singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
            item { Label("DNS RAPIDO") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (p in DNSS) Stat(p.n.uppercase(), dns[p.n]?.let { if (it < 0) "falhou" else "$it ms" } ?: "-", Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Testar", false) { job(false) { log = "> testando DNS..."; val b = bench(); log = if (b == null) "> sem resposta de DNS" else "> mais rapido: ${b.n} (${dns[b.n]} ms)" } }
                    Chip("Aplicar o melhor", true) { job(true) { log = "> testando DNS..."; val b = bench(); log = if (b == null) "> sem resposta de DNS" else "> DNS ${b.n} aplicado (" + apply(b) + ")" } }
                    Chip("Automatico", false) { job(true) { log = "> DNS automatico (" + withContext(Dispatchers.IO) { sh("settings put global private_dns_mode opportunistic") } + ")" } }
                }
            }
            item { Label("REDE") }
            item {
                ActionCard(A("Reduzir picos de ping", "Para buscas de Wi-Fi e Bluetooth em segundo plano", R.drawable.ic_shield, true) { "" }) {
                    job(true) { log = "> picos reduzidos (" + withContext(Dispatchers.IO) { sh(QUIET) } + ")" }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD).border(1.dp, EDGE, RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Rotas multiplas (relay)", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text("Reduz lag de rota. Precisa de servidores proprios.", color = GR, fontSize = 12.sp)
                    }
                    Text("EM BREVE", color = VI, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }
    }
}
