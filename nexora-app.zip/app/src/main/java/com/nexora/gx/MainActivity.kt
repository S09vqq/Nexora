package com.nexora.gx

import android.app.ActivityManager
import android.content.*
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku

val BG = Color(0xFF05070D); val CARD = Color(0xFF0E1420)
val CY = Color(0xFF00E5FF); val VI = Color(0xFF8A5CFF); val GR = Color(0xFF8A94A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } } }
}

fun stNow(): Int = try {
    if (!Shizuku.pingBinder()) 0 else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
} catch (e: Throwable) { 0 }

fun sh(cmd: String): String = try {
    val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
    m.isAccessible = true
    val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    val o = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
    p.waitFor(); o.trim().ifBlank { "Concluido" }
} catch (e: Throwable) { "Erro: ${e.cause?.message ?: e.message}" }

class A(val t: String, val d: String, val i: Int, val z: Boolean, val f: (String?) -> String)

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var st by remember { mutableIntStateOf(stNow()) }
    var log by remember { mutableStateOf("Sistema pronto.") }
    var sel by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf("") }
    val games = remember {
        val pm = ctx.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }.sortedBy { it.first.lowercase() }
    }
    LaunchedEffect(Unit) {
        while (true) {
            st = stNow()
            val mi = ActivityManager.MemoryInfo()
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val t = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)?.div(10f) ?: 0f
            info = "RAM livre ${mi.availMem / 1048576} MB   |   Bateria ${t} C"
            delay(1500)
        }
    }
    fun go(a: String): String { ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Aberto" }
    val anim = { v: String -> sh("settings put global window_animation_scale $v; settings put global transition_animation_scale $v; settings put global animator_duration_scale $v") }
    val acts = listOf(
        A("Limpar RAM", "Encerra processos em segundo plano", R.drawable.ic_ram, true) { sh("am kill-all") },
        A("Limpar cache do sistema", "Libera cache de todos os apps", R.drawable.ic_clean, true) { sh("pm trim-caches 999G") },
        A("Modo desempenho do jogo", "Aplica game mode performance ao jogo alvo", R.drawable.ic_boost, true) { p -> if (p == null) "Selecione um jogo" else sh("cmd game mode performance $p") },
        A("Compilar jogo (speed)", "Otimiza o codigo do jogo alvo, menos travadas", R.drawable.ic_game, true) { p -> if (p == null) "Selecione um jogo" else sh("cmd package compile -m speed -f $p") },
        A("Animacoes rapidas", "Reduz animacoes do sistema para 0.5x", R.drawable.ic_display, true) { anim("0.5") },
        A("Restaurar animacoes", "Volta as animacoes para 1x", R.drawable.ic_display, true) { anim("1.0") },
        A("Taxa de atualizacao maxima", "Forca a maior taxa de tela suportada", R.drawable.ic_display, true) { sh("settings put system min_refresh_rate 120; settings put system peak_refresh_rate 120") },
        A("Desativar economia de bateria", "Remove limite de desempenho", R.drawable.ic_shield, true) { sh("settings put global low_power 0") },
        A("Iniciar jogo alvo", "Abre o jogo selecionado", R.drawable.ic_game, false) { p ->
            if (p == null) "Selecione um jogo" else { ctx.startActivity(ctx.packageManager.getLaunchIntentForPackage(p)); "Aberto" } },
        A("Nao perturbe", "Permissao para silenciar durante o jogo", R.drawable.ic_shield, false) { go(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) },
        A("Opcoes do desenvolvedor", "Ajustes avancados de sistema", R.drawable.ic_boost, false) { go(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) },
        A("Otimizacao de bateria", "Gerencia apps em segundo plano", R.drawable.ic_ram, false) { go(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) },
        A("Armazenamento", "Analisa e libera espaco interno", R.drawable.ic_clean, false) { go(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
    )
    val line = Brush.horizontalGradient(listOf(CY, VI))
    LazyColumn(Modifier.fillMaxSize().background(BG), contentPadding = PaddingValues(16.dp, 40.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("NEXORA GX", fontSize = 32.sp, fontWeight = FontWeight.Black, color = CY, letterSpacing = 4.sp)
            Text("Otimizador de desempenho para jogos", color = GR, fontSize = 13.sp)
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD).border(1.dp, line, RoundedCornerShape(18.dp))
                .clickable { if (st == 1) Shizuku.requestPermission(1) }.padding(16.dp)) {
                Text("SHIZUKU  " + listOf("OFFLINE - abra o app Shizuku e inicie", "TOQUE PARA AUTORIZAR", "ATIVO")[st], color = if (st == 2) CY else VI, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp)); Text(info, color = Color.White, fontSize = 13.sp)
            }
        }
        item { Text("JOGO ALVO", color = GR, fontSize = 12.sp, letterSpacing = 3.sp) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(games) { g ->
                    val on = sel == g.second
                    Box(Modifier.clip(RoundedCornerShape(50)).background(if (on) VI else CARD).border(1.dp, if (on) CY else Color(0xFF1C2638), RoundedCornerShape(50))
                        .clickable { sel = g.second }.padding(14.dp, 8.dp)) { Text(g.first, color = Color.White, fontSize = 13.sp) }
                }
            }
        }
        item { Text("FUNCOES", color = GR, fontSize = 12.sp, letterSpacing = 3.sp) }
        items(acts) { a ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CARD).border(1.dp, Color(0xFF1C2638), RoundedCornerShape(16.dp))
                .clickable {
                    if (a.z && st != 2) { log = if (st == 1) "Autorize o Nexora no Shizuku" else "Inicie o servico do Shizuku"; if (st == 1) Shizuku.requestPermission(1) }
                    else scope.launch { log = "Executando ${a.t}..."; log = a.t + ": " + withContext(Dispatchers.IO) { a.f(sel) } }
                }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(painterResource(a.i), null, tint = CY, modifier = Modifier.size(28.dp))
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(a.t, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text(a.d, color = GR, fontSize = 12.sp)
                }
                Text(if (a.z) "SHIZUKU" else "LIVRE", color = if (a.z) VI else CY, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        item { Text(log, color = CY, fontSize = 12.sp) }
    }
}
