package com.nexora.gx

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.sin
import rikka.shizuku.Shizuku

val BG = Color(0xFF04060C); val CARD = Color(0xFF0B1220); val EDGE = Color(0xFF1C2638)
val CY = Color(0xFF00E5FF); val VI = Color(0xFF8A5CFF); val GR = Color(0xFF8A94A8); val OK = Color(0xFF39FFB0)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } } }
}

fun stNow(): Int = try {
    if (!Shizuku.pingBinder()) 0 else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
} catch (e: Throwable) { 0 }

fun sh(cmd: String): String = try {
    val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
    m.isAccessible = true
    val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    val o = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
    p.waitFor(); o.trim().ifBlank { "Concluido" }
} catch (e: Throwable) { "Erro: ${e.cause?.message ?: e.message}" }

class A(val t: String, val d: String, val i: Int, val z: Boolean, val ring: Boolean = false, val s: String = "", val f: (String?) -> String)

@Composable
fun Hero(used: Float, rot: Float, pulse: Float, d: Dp) {
    Box(Modifier.size(d), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 2.dp.toPx(); val o = 2.dp.toPx()
            val tl = Offset(o, o); val sz = Size(size.width - 2 * o, size.height - 2 * o)
            drawArc(EDGE, 0f, 360f, false, tl, sz, style = Stroke(1.dp.toPx()))
            rotate(rot) { drawArc(CY.copy(alpha = pulse), -90f, 50f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round)) }
            rotate(rot + 180f) { drawArc(VI.copy(alpha = pulse), -90f, 50f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round)) }
        }
        Canvas(Modifier.fillMaxSize().padding((d.value * 0.1f).dp)) {
            val sw = (d.value * 0.075f).dp.toPx()
            val tl = Offset(sw / 2, sw / 2); val sz = Size(size.width - sw, size.height - sw)
            drawArc(Color(0xFF111A2E), 0f, 360f, false, tl, sz, style = Stroke(sw))
            rotate(-90f) { drawArc(Brush.sweepGradient(listOf(CY, VI, CY)), 0f, 360f * used.coerceIn(0.02f, 1f), false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round)) }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${(used * 100).toInt()}%", color = Color.White, fontSize = (d.value * 0.2f).sp, fontWeight = FontWeight.Black)
            Text("RAM", color = GR, fontSize = 9.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun RingBtn(a: A, m: Modifier, click: () -> Unit) {
    val c = if (a.z) VI else CY
    Column(m.size(58.dp).clip(CircleShape).background(Brush.radialGradient(listOf(c.copy(alpha = 0.35f), CARD)))
        .border(1.dp, c.copy(alpha = 0.8f), CircleShape).clickable(onClick = click),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(painterResource(a.i), null, tint = c, modifier = Modifier.size(22.dp))
        Text(a.s.ifEmpty { a.t }, color = Color.White, fontSize = 8.sp, maxLines = 1, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Stat(l: String, v: String, m: Modifier) {
    Column(m.clip(RoundedCornerShape(16.dp)).background(CARD).border(1.dp, EDGE, RoundedCornerShape(16.dp)).padding(12.dp)) {
        Text(l, color = GR, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(4.dp))
        Text(v, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun Label(t: String) { Text(t, color = GR, fontSize = 12.sp, letterSpacing = 3.sp, modifier = Modifier.padding(top = 6.dp)) }

@Composable
fun Chip(t: String, on: Boolean, click: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (on) Brush.horizontalGradient(listOf(CY, VI)) else Brush.horizontalGradient(listOf(CARD, CARD)))
        .border(1.dp, if (on) Color.Transparent else EDGE, RoundedCornerShape(50)).clickable(onClick = click).padding(16.dp, 8.dp)) {
        Text(t, color = if (on) BG else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GameChip(n: String, on: Boolean, click: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(if (on) VI else CARD).border(1.dp, if (on) CY else EDGE, RoundedCornerShape(50))
        .clickable(onClick = click).padding(6.dp, 6.dp, 16.dp, 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(if (on) CY else EDGE), contentAlignment = Alignment.Center) {
            Text(n.take(1).uppercase(), color = if (on) BG else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(8.dp)); Text(n, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun ActionCard(a: A, click: () -> Unit) {
    val c = if (a.z) VI else CY
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(CARD, Color(0xFF0E1830))))
        .border(1.dp, Brush.horizontalGradient(listOf(c.copy(alpha = 0.6f), EDGE)), RoundedCornerShape(18.dp))
        .clickable(onClick = click).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(c.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Icon(painterResource(a.i), null, tint = c, modifier = Modifier.size(26.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(a.t, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(a.d, color = GR, fontSize = 12.sp)
        }
        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(c.copy(alpha = 0.15f)).padding(8.dp, 4.dp)) {
            Text(if (a.z) "SHIZUKU" else "LIVRE", color = c, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var st by remember { mutableIntStateOf(stNow()) }
    var log by remember { mutableStateOf("> sistema pronto") }
    var busy by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var avail by remember { mutableStateOf(0L) }
    var total by remember { mutableStateOf(1L) }
    var temp by remember { mutableStateOf(0f) }
    val games = remember {
        val pm = ctx.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }.sortedBy { it.first.lowercase() }
    }
    val inf = rememberInfiniteTransition(label = "inf")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "rot")
    val pulse by inf.animateFloat(0.4f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "pulse")
    LaunchedEffect(Unit) {
        while (true) {
            st = stNow()
            val mi = ActivityManager.MemoryInfo()
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            avail = mi.availMem; total = mi.totalMem
            temp = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)?.div(10f) ?: 0f
            delay(1500)
        }
    }
    fun go(a: String): String { ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Aberto" }
    val anim = { v: String -> sh("settings put global window_animation_scale $v; settings put global transition_animation_scale $v; settings put global animator_duration_scale $v") }
    fun app(p: String?, i: Intent): String = if (p == null) "Selecione um jogo" else { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Aberto" }
    val acts = listOf(
        A("Limpar RAM", "Encerra processos em segundo plano", R.drawable.ic_ram, true, true, "RAM") { sh("am kill-all") },
        A("Limpar cache do sistema", "Libera cache de todos os apps", R.drawable.ic_clean, true, true, "CACHE") { sh("pm trim-caches 999G") },
        A("Modo desempenho do jogo", "Aplica game mode performance ao jogo alvo", R.drawable.ic_boost, true, true, "MODO GAME") { p -> if (p == null) "Selecione um jogo" else sh("cmd game mode performance $p") },
        A("Animacoes rapidas", "Reduz animacoes do sistema para 0.5x", R.drawable.ic_display, true, true, "ANIM") { anim("0.5") },
        A("Taxa de atualizacao maxima", "Forca a maior taxa de tela suportada", R.drawable.ic_display, true, true, "HZ MAX") { sh("settings put system min_refresh_rate 120; settings put system peak_refresh_rate 120") },
        A("Desativar economia de bateria", "Remove limite de desempenho", R.drawable.ic_shield, true, true, "ENERGIA") { sh("settings put global low_power 0") },
        A("Compilar jogo (speed)", "Otimiza o codigo do jogo alvo, menos travadas", R.drawable.ic_game, true, true, "COMPILAR") { p -> if (p == null) "Selecione um jogo" else sh("cmd package compile -m speed -f $p") },
        A("Iniciar jogo alvo", "Abre o jogo selecionado", R.drawable.ic_game, false, true, "JOGAR") { p ->
            if (p == null) "Selecione um jogo" else { ctx.startActivity(ctx.packageManager.getLaunchIntentForPackage(p)); "Aberto" } },
        A("Parar jogo alvo", "Forca a parada do jogo selecionado", R.drawable.ic_power, true) { p -> if (p == null) "Selecione um jogo" else sh("am force-stop $p") },
        A("Limpar cache do jogo", "Apaga so o cache do jogo alvo", R.drawable.ic_clean, true) { p -> if (p == null) "Selecione um jogo" else sh("pm clear --cache-only $p") },
        A("Livrar jogo do Doze", "Impede o sistema de suspender o jogo", R.drawable.ic_shield, true) { p -> if (p == null) "Selecione um jogo" else sh("cmd deviceidle whitelist +$p") },
        A("Brilho maximo", "Brilho manual no maximo", R.drawable.ic_sun, true) { sh("settings put system screen_brightness_mode 0; settings put system screen_brightness 255") },
        A("Restaurar animacoes", "Volta as animacoes para 1x", R.drawable.ic_display, true) { anim("1.0") },
        A("Restaurar resolucao", "Reseta tamanho e densidade da tela", R.drawable.ic_display, true) { sh("wm size reset; wm density reset") },
        A("Info do jogo alvo", "Detalhes e permissoes do app", R.drawable.ic_game, false) { p -> app(p, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))) },
        A("Tela e brilho", "Ajustes de display", R.drawable.ic_sun, false) { go(Settings.ACTION_DISPLAY_SETTINGS) },
        A("Som e vibracao", "Ajustes de audio", R.drawable.ic_ram, false) { go(Settings.ACTION_SOUND_SETTINGS) },
        A("Wi-Fi", "Escolha a melhor rede para jogar", R.drawable.ic_shield, false) { go(Settings.ACTION_WIFI_SETTINGS) },
        A("Nao perturbe", "Permissao para silenciar durante o jogo", R.drawable.ic_shield, false) { go(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) },
        A("Opcoes do desenvolvedor", "Ajustes avancados de sistema", R.drawable.ic_boost, false) { go(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) },
        A("Otimizacao de bateria", "Gerencia apps em segundo plano", R.drawable.ic_ram, false) { go(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) },
        A("Armazenamento", "Analisa e libera espaco interno", R.drawable.ic_clean, false) { go(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
    )
    val ring = acts.filter { it.ring }
    val boostSet = setOf("Limpar RAM", "Limpar cache do sistema", "Animacoes rapidas", "Desativar economia de bateria", "Modo desempenho do jogo")
    fun needShizuku(): Boolean {
        if (st == 2) return false
        log = if (st == 1) "> autorize o Nexora no Shizuku" else "> inicie o servico do Shizuku"
        if (st == 1) Shizuku.requestPermission(1)
        return true
    }
    fun exec(a: A) {
        if (busy || (a.z && needShizuku())) return
        scope.launch {
            busy = true; log = "> ${a.t}..."
            val r = withContext(Dispatchers.IO) { a.f(sel) }
            log = "> ${a.t}\n$r"; busy = false
        }
    }
    fun boost() {
        if (busy || needShizuku()) return
        val seq = acts.filter { it.t in boostSet && (sel != null || it.t != "Modo desempenho do jogo") }
        scope.launch {
            busy = true; val sb = StringBuilder()
            for (a in seq) {
                log = "> ${a.t}..."
                val r = withContext(Dispatchers.IO) { a.f(sel) }
                sb.append("> ${a.t}: ${r.lines().firstOrNull() ?: ""}\n")
            }
            log = sb.toString().trim() + "\n> otimizacao concluida"; busy = false
        }
    }
    val shown = acts.filter { filter == 0 || (filter == 1 && it.z) || (filter == 2 && !it.z) }
    val used = 1f - avail.toFloat() / total.toFloat()
    val sc = listOf(Color(0xFFFF5470), Color(0xFFFFC857), OK)[st]
    if (tab == 1) { NetScreen(st) { tab = 0 }; return }
    Row(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1233), BG, BG))).padding(24.dp, 14.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Column(Modifier.weight(0.95f).fillMaxHeight().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row {
                        Text("NEXORA", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 3.sp)
                        Text(" GX", fontSize = 24.sp, fontWeight = FontWeight.Black, color = CY, letterSpacing = 3.sp)
                    }
                    Text("Game performance suite", color = GR, fontSize = 11.sp)
                }
                Row(Modifier.clip(RoundedCornerShape(50)).background(CARD).border(1.dp, sc.copy(alpha = 0.6f), RoundedCornerShape(50))
                    .clickable { if (st == 1) Shizuku.requestPermission(1) }.padding(12.dp, 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(sc))
                    Spacer(Modifier.width(8.dp))
                    Text(listOf("SHIZUKU OFF", "AUTORIZAR", "SHIZUKU ATIVO")[st], color = sc, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.size(274.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(EDGE, radius = 108.dp.toPx(), style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))))
                }
                Hero(used, rot, pulse, 118.dp)
                ring.forEachIndexed { i, a ->
                    val ang = Math.toRadians(-90.0 + i * 360.0 / ring.size)
                    RingBtn(a, Modifier.offset((108 * cos(ang)).dp, (108 * sin(ang)).dp)) { exec(a) }
                }
            }
        }
        LazyColumn(Modifier.weight(1.05f).fillMaxHeight(), contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Stat("RAM LIVRE", "${avail / 1048576} MB", Modifier.weight(1f))
                    Stat("TEMP", "$temp C", Modifier.weight(1f))
                    Stat("ALVO", games.firstOrNull { it.second == sel }?.first ?: "nenhum", Modifier.weight(1f))
                }
            }
            item {
                Box(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(Brush.horizontalGradient(listOf(CY, VI)))
                    .clickable { boost() }, contentAlignment = Alignment.Center) {
                    Text(if (busy) "OTIMIZANDO..." else "OTIMIZAR AGORA", color = BG, fontWeight = FontWeight.Black, fontSize = 14.sp, letterSpacing = 3.sp)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF060A14)).border(1.dp, EDGE, RoundedCornerShape(16.dp)).padding(12.dp)) {
                    Text("CONSOLE", color = GR, fontSize = 10.sp, letterSpacing = 3.sp)
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp), color = CY, trackColor = EDGE)
                    Text(log, color = OK, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
            item { Chip("ANTI-LAG / REDE", true) { tab = 1 } }
            item { Label("JOGO ALVO") }
            item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(games) { g -> GameChip(g.first, sel == g.second) { sel = g.second } } } }
            item { Label("FUNCOES") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Todas", filter == 0) { filter = 0 }
                    Chip("Shizuku", filter == 1) { filter = 1 }
                    Chip("Livres", filter == 2) { filter = 2 }
                }
            }
            items(shown) { a -> ActionCard(a) { exec(a) } }
        }
    }
}
