package com.nexora.gx

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.TrafficStats
import android.os.BatteryManager
import android.view.WindowManager
import android.content.pm.ApplicationInfo
import android.os.Build
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

val BK = Color(0xFF0A0A0B); val PN = Color(0xFF141416); val LN = Color(0xFF2A2A30)
val RD = Color(0xFFFF2D3F); val WH = Color.White; val GY = Color(0xFF8D8D96); val GN = Color(0xFF3DDC84); val YL = Color(0xFFFFC857)
val CUT = CutCornerShape(topStart = 14.dp, topEnd = 0.dp, bottomEnd = 14.dp, bottomStart = 0.dp)
fun Modifier.panel(c: Color = LN): Modifier = this.clip(CUT).background(PN).border(1.dp, c, CUT)

class Node(val n: String, val h: String)
class DnsP(val n: String, val ip: String, val host: String)
val NODES = listOf(
    Node("Sao Paulo", "ec2.sa-east-1.amazonaws.com"), Node("Virginia", "ec2.us-east-1.amazonaws.com"),
    Node("Ohio", "ec2.us-east-2.amazonaws.com"), Node("California", "ec2.us-west-1.amazonaws.com"),
    Node("Oregon", "ec2.us-west-2.amazonaws.com"), Node("Londres", "ec2.eu-west-2.amazonaws.com"),
    Node("Frankfurt", "ec2.eu-central-1.amazonaws.com"), Node("Toquio", "ec2.ap-northeast-1.amazonaws.com"),
    Node("Singapura", "ec2.ap-southeast-1.amazonaws.com"), Node("Sydney", "ec2.ap-southeast-2.amazonaws.com"))
val DNSS = listOf(DnsP("Cloudflare", "1.1.1.1", "one.one.one.one"), DnsP("Google", "8.8.8.8", "dns.google"),
    DnsP("Quad9", "9.9.9.9", "dns.quad9.net"), DnsP("AdGuard", "94.140.14.14", "dns.adguard-dns.com"))
const val QUIET = "settings put global wifi_scan_always_enabled 0; settings put global ble_scan_always_enabled 0"

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } } }
}

fun stNow(): Int = try {
    if (!Shizuku.pingBinder()) 0 else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
} catch (e: Throwable) { 0 }

fun sh(cmd: String): String = try {
    val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
    m.isAccessible = true
    val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    val o = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
    p.waitFor(); o.trim().ifBlank { "ok" }
} catch (e: Throwable) { "erro: ${e.cause?.message ?: e.message}" }

fun tcpMs(a: InetAddress, p: Int): Long = try {
    val t = System.nanoTime()
    Socket().use { it.connect(InetSocketAddress(a, p), 1500) }
    (System.nanoTime() - t) / 1_000_000
} catch (e: Throwable) { -1L }

fun dnsMs(ip: String): Long = try {
    val q = ByteArrayOutputStream(); val o = DataOutputStream(q)
    o.writeShort(0x1234); o.writeShort(0x0100); o.writeShort(1); o.writeShort(0); o.writeShort(0); o.writeShort(0)
    for (l in "google.com".split(".")) { o.writeByte(l.length); o.writeBytes(l) }
    o.writeByte(0); o.writeShort(1); o.writeShort(1)
    val b = q.toByteArray()
    DatagramSocket().use { s ->
        s.soTimeout = 1500
        val t = System.nanoTime()
        s.send(DatagramPacket(b, b.size, InetAddress.getByName(ip), 53))
        val r = ByteArray(512); s.receive(DatagramPacket(r, r.size))
        (System.nanoTime() - t) / 1_000_000
    }
} catch (e: Throwable) { -1L }

@Composable
fun Chip(t: String, on: Boolean, click: () -> Unit) {
    Box(Modifier.clip(CUT).background(if (on) RD else PN).border(1.dp, if (on) RD else LN, CUT).clickable(onClick = click).padding(14.dp, 8.dp)) {
        Text(t, color = WH, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
fun Stat(l: String, v: String, m: Modifier) {
    Column(m.panel().padding(10.dp)) {
        Text(l, color = GY, fontSize = 9.sp, letterSpacing = 2.sp)
        Text(v, color = WH, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun Label(t: String) { Text(t, color = GY, fontSize = 11.sp, letterSpacing = 3.sp, modifier = Modifier.padding(top = 6.dp)) }

@Composable
fun Radar(ping: Map<String, Long>, best: String?, rot: Float, d: Dp) {
    Canvas(Modifier.size(d)) {
        val c = center; val r = size.minDimension / 2 - 3.dp.toPx()
        for (k in 1..3) drawCircle(LN, r * k / 3f, style = Stroke(1.dp.toPx()))
        drawLine(LN, Offset(c.x - r, c.y), Offset(c.x + r, c.y), 1.dp.toPx())
        drawLine(LN, Offset(c.x, c.y - r), Offset(c.x, c.y + r), 1.dp.toPx())
        rotate(rot) {
            drawArc(RD.copy(alpha = 0.22f), -35f, 35f, true, Offset(c.x - r, c.y - r), Size(2 * r, 2 * r))
            drawLine(RD, c, Offset(c.x + r, c.y), 2.dp.toPx())
        }
        NODES.forEachIndexed { i, n ->
            val ms = ping[n.n] ?: return@forEachIndexed
            if (ms < 0) return@forEachIndexed
            val a = Math.toRadians(i * 36.0 - 90.0)
            val rad = r * (minOf(ms, 300L) / 300f).coerceIn(0.12f, 1f)
            val p = Offset(c.x + (rad * cos(a)).toFloat(), c.y + (rad * sin(a)).toFloat())
            if (n.n == best) { drawCircle(RD.copy(alpha = 0.3f), 10.dp.toPx(), p); drawCircle(RD, 5.dp.toPx(), p) }
            else drawCircle(WH, 3.dp.toPx(), p)
        }
    }
}

@Composable
fun RouteRow(i: Int, n: Node, ms: Long?, best: Boolean, sel: Boolean, click: () -> Unit) {
    Row(Modifier.fillMaxWidth().panel(if (sel) RD else LN).clickable(onClick = click).padding(12.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("%02d".format(i + 1), color = if (best) RD else GY, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Text(n.n.uppercase(), color = WH, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(112.dp).padding(start = 12.dp))
        Box(Modifier.weight(1f).height(5.dp).background(LN)) {
            if (ms != null && ms >= 0) Box(Modifier.fillMaxWidth((1f - minOf(ms, 300L) / 300f).coerceIn(0.06f, 1f)).fillMaxHeight().background(if (best) RD else WH.copy(alpha = 0.75f)))
        }
        Text(if (ms == null) "-" else if (ms < 0) "off" else "$ms ms", color = if (best) RD else WH, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.width(66.dp).padding(start = 10.dp), textAlign = TextAlign.End)
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var st by remember { mutableIntStateOf(stNow()) }
    val ping = remember { mutableStateMapOf<String, Long>() }
    val dns = remember { mutableStateMapOf<String, Long>() }
    val samples = remember { mutableStateListOf<Long>() }
    var route by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val prefs = remember { ctx.getSharedPreferences("nx", 0) }
    var prof by remember { mutableIntStateOf(prefs.getInt("prof", 2)) }
    val hist = remember { Hist().also { it.last = prefs.getString("last", "Sem sessao ainda") ?: "" } }
    var bg by remember { mutableStateOf(RouteService.running) }
    var auto by remember { mutableStateOf(prefs.getBoolean("auto", false)) }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun toggleBg() {
        if (bg) { ctx.stopService(Intent(ctx, RouteService::class.java)); bg = false }
        else {
            if (Build.VERSION.SDK_INT >= 33) permL.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            ContextCompat.startForegroundService(ctx, Intent(ctx, RouteService::class.java)); bg = true
        }
    }
    var log by remember { mutableStateOf("> pronto. toque em ATIVAR ROTA") }
    val games = remember {
        val pm = ctx.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }.sortedBy { it.first.lowercase() }
    }
    val rot by rememberInfiniteTransition(label = "i").animateFloat(0f, 360f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "r")
    fun best(): Node? = NODES.filter { (ping[it.n] ?: -1L) >= 0 }.minByOrNull { ping[it.n]!! }
    val active = NODES.firstOrNull { it.n == route } ?: best()
    LaunchedEffect(Unit) { while (true) { st = stNow(); delay(1500) } }
    LaunchedEffect(Unit) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var pt = 0L; var pi = 0L; var prx = TrafficStats.getTotalRxBytes()
        while (true) {
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            hist.availMb = mi.availMem / 1048576
            hist.ram.cap(100f * (1f - mi.availMem.toFloat() / mi.totalMem.toFloat()))
            val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            hist.tempC = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            hist.bat = (bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / (bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
            hist.temp.cap(hist.tempC); hist.batH.cap(hist.bat.toFloat())
            @Suppress("DEPRECATION") val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION") val rr = wm.defaultDisplay.refreshRate
            hist.hz = rr
            val rx = TrafficStats.getTotalRxBytes()
            if (rx >= 0 && prx >= 0) { hist.netKb = ((rx - prx) / 1.5f / 1024f).toInt(); hist.net.cap(hist.netKb.toFloat()) }
            prx = rx
            if (st == 2) {
                val f = withContext(Dispatchers.IO) { sh("head -1 /proc/stat") }.split(" ").mapNotNull { it.toLongOrNull() }
                if (f.size >= 5) {
                    val tot = f.sum(); val idle = f[3] + f[4]
                    if (pt > 0) { hist.cpuNow = (100f * (1f - (idle - pi).toFloat() / (tot - pt).coerceAtLeast(1L))).toInt().coerceIn(0, 100); hist.cpu.cap(hist.cpuNow.toFloat()) }
                    pt = tot; pi = idle
                }
            }
            hist.ping.cap(maxOf(0L, samples.lastOrNull() ?: 0L).toFloat())
            delay(1500)
        }
    }
    LaunchedEffect(active?.n) {
        samples.clear()
        val a = withContext(Dispatchers.IO) { try { InetAddress.getByName(active?.h ?: return@withContext null) } catch (e: Throwable) { null } } ?: return@LaunchedEffect
        while (true) {
            samples.add(withContext(Dispatchers.IO) { tcpMs(a, 443) })
            if (samples.size > 30) samples.removeAt(0)
            delay(900)
        }
    }
    val ok = samples.filter { it >= 0 }
    val avg = if (ok.isEmpty()) 0 else ok.average().toInt()
    val jit = if (ok.size > 1) ok.zipWithNext { a, b -> abs(a - b) }.average().toInt() else 0
    val loss = if (samples.isEmpty()) 0 else 100 * (samples.size - ok.size) / samples.size
    val last = samples.lastOrNull() ?: -1L
    val (ql, qc) = when {
        samples.isEmpty() -> "AGUARDANDO" to GY
        loss > 10 || avg > 150 -> "RUIM" to RD
        avg > 80 -> "MEDIO" to YL
        avg > 40 -> "BOM" to WH
        else -> "EXCELENTE" to GN
    }
    fun needSh(): Boolean { if (st == 2) return false; log = "> ative e autorize o Shizuku"; return true }
    suspend fun scanAll() {
        val r = withContext(Dispatchers.IO) {
            coroutineScope {
                NODES.map { n -> async {
                    val a = try { InetAddress.getByName(n.h) } catch (e: Throwable) { null }
                    n.n to (if (a == null) -1L else List(3) { tcpMs(a, 443) }.filter { it >= 0 }.minOrNull() ?: -1L)
                } }.awaitAll()
            }
        }
        r.forEach { ping[it.first] = it.second }
    }
    suspend fun bench(): DnsP? {
        dns.clear()
        for (p in DNSS) dns[p.n] = withContext(Dispatchers.IO) { listOf(dnsMs(p.ip), dnsMs(p.ip)).filter { it >= 0 }.minOrNull() ?: -1L }
        return DNSS.filter { (dns[it.n] ?: -1L) >= 0 }.minByOrNull { dns[it.n]!! }
    }
    suspend fun applyDns(b: DnsP): String = withContext(Dispatchers.IO) { sh("settings put global private_dns_mode hostname; settings put global private_dns_specifier ${b.host}") }
    fun job(needs: Boolean, f: suspend () -> Unit) {
        if (busy || (needs && needSh())) return
        scope.launch { busy = true; try { f() } finally { busy = false } }
    }
    fun activate() = job(false) {
        log = "> varrendo ${NODES.size} rotas..."; scanAll()
        val b = best(); route = b?.n
        val sb = StringBuilder(if (b == null) "> sem resposta de rede" else "> melhor rota: ${b.n} (${ping[b.n]} ms)")
        if (st == 2) {
            log = sb.append("\n> otimizando DNS...").toString()
            val d = bench(); if (d != null) { applyDns(d); sb.append("\n> DNS ${d.n} aplicado") }
            withContext(Dispatchers.IO) { sh("am kill-all; $QUIET") }; sb.append("\n> RAM limpa, picos reduzidos")
            sel?.let { p -> withContext(Dispatchers.IO) { sh("cmd game mode performance $p") }; sb.append("\n> modo desempenho no jogo") }
        } else sb.append("\n> ative o Shizuku para aplicar DNS e limpeza")
        log = sb.append("\n> pronto").toString()
    }
    fun optimize() = job(true) {
        val p = PROFS[prof]; val r0 = hist.availMb
        log = "> aplicando perfil ${p.n}..."
        val r = withContext(Dispatchers.IO) { applyProfile(p, null) }
        scanAll(); route = best()?.n
        delay(800)
        hist.last = "Ultima sessao: RAM livre $r0 MB -> ${hist.availMb} MB (${p.n})"
        prefs.edit().putString("last", hist.last).apply()
        log = "> perfil ${p.n} aplicado ($r)\n> melhor rota: ${route ?: "nenhuma"}"
    }
    fun playGame(p: String) = job(false) {
        val pr = PROFS[prefs.getInt("gp_$p", prof)]
        if (st == 2) { log = "> $p: perfil ${pr.n}"; withContext(Dispatchers.IO) { applyProfile(pr, p) } }
        ctx.packageManager.getLaunchIntentForPackage(p)?.let { ctx.startActivity(it) }
    }
    fun cleanJob() = job(true) { log = "> limpando..."; hist.clean = cleanNow(ctx, hist); log = "> limpeza concluida" }
    val act = Act(
        optimize = { optimize() },
        setProf = { prof = it; prefs.edit().putInt("prof", it).apply() },
        activate = { activate() },
        scan = { job(false) { log = "> varrendo..."; scanAll(); route = best()?.n; log = "> rotas atualizadas" } },
        selRoute = { route = it }, play = { p -> playGame(p) }, clean = { cleanJob() },
        setAuto = { on -> auto = on; prefs.edit().putBoolean("auto", on).apply(); if (on) ContextCompat.startForegroundService(ctx, Intent(ctx, RouteService::class.java)) },
        go = { tab = it })
    LaunchedEffect(Unit) { scanAll(); if (route == null) route = best()?.n }
    val sorted = NODES.sortedBy { n -> ping[n.n]?.takeIf { it >= 0 } ?: Long.MAX_VALUE }
    val sc = listOf(RD, YL, GN)[st]
    Column(Modifier.fillMaxSize().background(BK)) {
    Row(Modifier.weight(1f).fillMaxWidth()) {
    NavRail(tab, st, { if (st == 1) Shizuku.requestPermission(1) }) { tab = it }
    val mm = Modifier.weight(1f).fillMaxHeight().padding(20.dp, 14.dp)
    when (tab) {
        0 -> HomePage(mm, hist, ping, sorted, active?.n, best()?.n, last, jit, loss, prof, st, busy, auto, log, act)
        2 -> GamePage(mm, st, prof, 0)
        7 -> GamePage(mm, st, prof, 1)
        3 -> MonitorPage(mm, hist)
        4 -> CleanPage(mm, st, hist)
        5 -> PerfisPage(mm, prof) { prof = it; prefs.edit().putInt("prof", it).apply() }
        6 -> PremiumPage(mm)
        else -> Row(mm, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Column(Modifier.weight(0.95f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row {
                        Text("NEXORA", fontSize = 24.sp, fontWeight = FontWeight.Black, color = WH, letterSpacing = 3.sp)
                        Text(" GX", fontSize = 24.sp, fontWeight = FontWeight.Black, color = RD, letterSpacing = 3.sp)
                    }
                    Box(Modifier.width(44.dp).height(3.dp).background(RD))
                }
                Row(Modifier.panel(sc).clickable { if (st == 1) Shizuku.requestPermission(1) }.padding(12.dp, 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(sc))
                    Spacer(Modifier.width(8.dp))
                    Text(listOf("SHIZUKU OFF", "AUTORIZAR", "SHIZUKU ATIVO")[st], color = WH, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Radar(ping, best()?.n, rot, 190.dp)
                Column(Modifier.weight(1f)) {
                    Text("ROTA ATIVA", color = GY, fontSize = 10.sp, letterSpacing = 3.sp)
                    Text(active?.n?.uppercase() ?: "NENHUMA", color = WH, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(if (last >= 0) "$last" else "--", color = WH, fontSize = 46.sp, fontWeight = FontWeight.Black)
                        Text(" ms", color = GY, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    Text(ql, color = qc, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("MEDIA", "$avg ms", Modifier.weight(1f)); Stat("JITTER", "$jit ms", Modifier.weight(1f)); Stat("PERDA", "$loss%", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth().height(52.dp).clip(CUT).background(RD).clickable { activate() }, horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(painterResource(R.drawable.ic_boost), null, tint = WH, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Text(if (busy) "TRABALHANDO..." else "ATIVAR ROTA", color = WH, fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = 3.sp)
            }
        }
        LazyColumn(Modifier.weight(1.05f).fillMaxHeight(), contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Column(Modifier.fillMaxWidth().panel().padding(12.dp)) {
                    Text("CONSOLE", color = GY, fontSize = 10.sp, letterSpacing = 3.sp)
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp), color = RD, trackColor = LN)
                    Text(log, color = WH, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("ROTAS", color = GY, fontSize = 11.sp, letterSpacing = 3.sp, modifier = Modifier.weight(1f))
                    Chip("VARRER", false) { job(false) { log = "> varrendo..."; scanAll(); route = best()?.n; log = "> rotas atualizadas" } }
                }
            }
            item { Chip(if (bg) "SEGUNDO PLANO: LIGADO" else "SEGUNDO PLANO: DESLIGADO", bg) { toggleBg() } }
            itemsIndexed(sorted) { i, n -> RouteRow(i, n, ping[n.n], n.n == best()?.n, n.n == active?.n) { route = n.n } }
            item { Label("DNS") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (p in DNSS) Stat(p.n.uppercase(), dns[p.n]?.let { if (it < 0) "falhou" else "$it ms" } ?: "-", Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("TESTAR", false) { job(false) { log = "> testando DNS..."; val b = bench(); log = if (b == null) "> sem resposta de DNS" else "> mais rapido: ${b.n} (${dns[b.n]} ms)" } }
                    Chip("APLICAR O MELHOR", true) { job(true) { log = "> testando DNS..."; val b = bench(); log = if (b == null) "> sem resposta de DNS" else "> DNS ${b.n}: " + applyDns(b) } }
                    Chip("AUTO", false) { job(true) { log = "> DNS automatico: " + withContext(Dispatchers.IO) { sh("settings put global private_dns_mode opportunistic") } } }
                }
            }
            item { Label("JOGO") }
            item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(games) { g -> Chip(g.first, sel == g.second) { sel = if (sel == g.second) null else g.second } } } }
        }
    }
    }
    }
    }
}
