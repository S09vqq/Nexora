package com.nexora.gx

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Environment
import android.os.StatFs
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Prof(val n: String, val c: Color, val hz: Int, val anim: String, val kill: Boolean, val lp: Int, val mode: String, val d: String)
val PROFS = listOf(
    Prof("ULTRA PERFORMANCE", RD, 120, "0.5", true, 0, "performance", "120 Hz, animacoes 0.5x, limpa RAM, modo desempenho"),
    Prof("GAMING", Color(0xFFFF8A3D), 90, "0.5", true, 0, "performance", "90 Hz, animacoes 0.5x, limpa RAM, modo desempenho"),
    Prof("EQUILIBRADO", GN, 0, "1.0", false, 0, "standard", "Hz automatico, animacoes normais"),
    Prof("BATERIA", Color(0xFF4DA3FF), 60, "1.0", false, 1, "battery", "60 Hz, economia de bateria ligada"))

fun applyProfile(p: Prof, pkg: String?): String {
    val c = ArrayList<String>()
    c.add(if (p.hz == 0) "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        else "settings put system min_refresh_rate ${p.hz}; settings put system peak_refresh_rate ${p.hz}")
    c.add("settings put global window_animation_scale ${p.anim}; settings put global transition_animation_scale ${p.anim}; settings put global animator_duration_scale ${p.anim}")
    c.add("settings put global low_power ${p.lp}")
    if (p.kill) c.add("am kill-all")
    if (pkg != null) c.add("cmd game mode ${p.mode} $pkg")
    return sh(c.joinToString("; "))
}

fun <T> MutableList<T>.cap(v: T) { add(v); if (size > 60) removeAt(0) }

class Hist {
    val ram = mutableStateListOf<Float>(); val cpu = mutableStateListOf<Float>(); val temp = mutableStateListOf<Float>()
    val ping = mutableStateListOf<Float>(); val net = mutableStateListOf<Float>(); val batH = mutableStateListOf<Float>()
    var availMb by mutableStateOf(0L); var tempC by mutableStateOf(0f); var bat by mutableStateOf(0)
    var hz by mutableStateOf(0f); var cpuNow by mutableStateOf(0); var netKb by mutableStateOf(0)
    var last by mutableStateOf("")
    var clean by mutableStateOf(listOf<Pair<String, String>>())
}

class AppI(val n: String, val p: String, val ic: ImageBitmap, val sys: Boolean)
class Mon(val t: String, val v: String, val l: List<Float>, val mx: Float, val c: Color)

fun iconOf(ctx: Context, p: String): ImageBitmap? = try { ctx.packageManager.getApplicationIcon(p).toBitmap(96, 96).asImageBitmap() } catch (e: Throwable) { null }

@Composable
fun Spark(v: List<Float>, c: Color, mx: Float, m: Modifier) {
    Canvas(m) {
        if (v.size < 2) return@Canvas
        val dx = size.width / 59f; val p = Path()
        v.forEachIndexed { i, y ->
            val py = size.height - (y / mx).coerceIn(0f, 1f) * size.height
            if (i == 0) p.moveTo(0f, py) else p.lineTo(i * dx, py)
        }
        drawPath(p, c, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
    }
}

@Composable
fun AppCell(a: AppI, on: Boolean, click: () -> Unit) {
    Column(Modifier.clip(CUT).background(if (on) RD.copy(alpha = 0.25f) else PN).border(1.dp, if (on) RD else LN, CUT).clickable(onClick = click).padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Image(a.ic, null, Modifier.size(44.dp))
        Text(a.n, color = WH, fontSize = 9.sp, maxLines = 1)
    }
}

class Act(val optimize: () -> Unit, val setProf: (Int) -> Unit, val activate: () -> Unit, val scan: () -> Unit, val selRoute: (String) -> Unit,
    val play: (String) -> Unit, val clean: () -> Unit, val setAuto: (Boolean) -> Unit, val go: (Int) -> Unit)

fun qual(ms: Long, loss: Int): Pair<String, Color> = when {
    ms < 0 -> "--" to GY
    loss > 10 || ms > 150 -> "Ruim" to RD
    ms > 80 -> "Medio" to YL
    ms > 40 -> "Bom" to WH
    else -> "Excelente" to GN
}

@Composable
fun T(t: String, c: Color = WH, s: Int = 11, w: FontWeight = FontWeight.Normal, m: Modifier = Modifier) =
    Text(t, color = c, fontSize = s.sp, fontWeight = w, maxLines = 1, modifier = m)

@Composable
fun Btn(t: String, m: Modifier = Modifier, filled: Boolean = true, click: () -> Unit) {
    Box(m.clip(CUT).background(if (filled) RD else PN).border(1.dp, if (filled) RD else LN, CUT).clickable(onClick = click).padding(8.dp, 9.dp), contentAlignment = Alignment.Center) {
        T(t, WH, 10, FontWeight.Black)
    }
}

@Composable
fun Sw(on: Boolean, change: (Boolean) -> Unit) {
    Box(Modifier.width(36.dp).height(18.dp).clip(RoundedCornerShape(9.dp)).background(if (on) RD else LN).clickable { change(!on) }) {
        Box(Modifier.padding(2.dp).size(14.dp).align(if (on) Alignment.CenterEnd else Alignment.CenterStart).clip(CircleShape).background(WH))
    }
}

@Composable
fun Pane(title: String, m: Modifier, link: String = "", go: () -> Unit = {}, body: @Composable ColumnScope.() -> Unit) {
    Column(m.panel().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            T(title, WH, 10, FontWeight.Black, Modifier.weight(1f))
            if (link.isNotEmpty()) Text(link, color = GY, fontSize = 9.sp, modifier = Modifier.clickable(onClick = go))
        }
        body()
    }
}

@Composable
fun Gauge(l: String, v: Int, t: String, c: Color) {
    Box(Modifier.size(54.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(2.dp)) {
            val sw = 5.dp.toPx(); val tl = Offset(sw / 2, sw / 2); val sz = Size(size.width - sw, size.height - sw)
            drawArc(LN, 0f, 360f, false, tl, sz, style = Stroke(sw))
            drawArc(c, -90f, 360f * v.coerceIn(0, 100) / 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) { T(l, GY, 7); T(t, WH, 10, FontWeight.Black) }
    }
}

@Composable
fun Metric(l: String, v: String, s: String, c: Color, d: List<Float>, mx: Float, m: Modifier) {
    Column(m) {
        T(l, GY, 8); T(v, WH, 15, FontWeight.Black); T(s, c, 9)
        Spark(d, c, mx, Modifier.fillMaxWidth().height(20.dp))
    }
}

@Composable
fun Bars(ms: Long, c: Color) {
    val n = when { ms < 0 -> 0; ms < 50 -> 4; ms < 100 -> 3; ms < 160 -> 2; else -> 1 }
    Row(horizontalArrangement = Arrangement.spacedBy(1.dp), verticalAlignment = Alignment.Bottom) {
        for (i in 1..4) Box(Modifier.width(3.dp).height((3 + i * 2).dp).background(if (i <= n) c else LN))
    }
}

@Composable
fun GameMini(p: String, m: Modifier, play: (String) -> Unit) {
    val ctx = LocalContext.current
    val ic = remember(p) { iconOf(ctx, p) }
    val lb = remember(p) { try { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(p, 0)).toString() } catch (e: Throwable) { p } }
    Column(m.panel().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        if (ic != null) Image(ic, null, Modifier.size(28.dp)) else Box(Modifier.size(28.dp).background(LN))
        T(lb, WH, 8, FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth().clip(CUT).border(1.dp, RD, CUT).clickable { play(p) }.padding(vertical = 3.dp), horizontalArrangement = Arrangement.Center) { T("OTIMIZAR", RD, 7, FontWeight.Black) }
    }
}

@Composable
fun TopBar(st: Int, onShizuku: () -> Unit) {
    val now by produceState("") { while (true) { value = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); delay(10000) } }
    val day by produceState("") { value = SimpleDateFormat("EEE, dd/MM/yyyy", Locale.getDefault()).format(Date()) }
    val sc = listOf(RD, YL, GN)[st]
    Row(Modifier.fillMaxWidth().background(PN).padding(14.dp, 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { T(now, WH, 18, FontWeight.Black); T(day, GY, 9) }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row {
                Text("NEXORA", fontSize = 22.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, color = WH, letterSpacing = 2.sp)
                Text(" GX", fontSize = 22.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, color = RD, letterSpacing = 2.sp)
            }
            Text("SEU JOGO, NOSSO FOCO", color = GY, fontSize = 8.sp, letterSpacing = 3.sp)
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.panel(sc).clickable(onClick = onShizuku).padding(10.dp, 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(sc)); Spacer(Modifier.width(6.dp))
                T(listOf("SHIZUKU OFF", "AUTORIZAR", "SHIZUKU ATIVO")[st], WH, 9, FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.panel(RD).padding(10.dp, 3.dp), horizontalAlignment = Alignment.CenterHorizontally) { T("PREMIUM", RD, 10, FontWeight.Black); T("ATIVO", WH, 8) }
        }
    }
}

@Composable
fun NavRail(tab: Int, pick: (Int) -> Unit) {
    val entries = listOf(Triple("Inicio", R.drawable.ic_home, 0), Triple("Game Boost", R.drawable.ic_boost, 2), Triple("Rotas", R.drawable.ic_route, 1),
        Triple("Jogos", R.drawable.ic_game, 7), Triple("Monitor", R.drawable.ic_chart, 3), Triple("Limpeza", R.drawable.ic_clean, 4),
        Triple("Perfis", R.drawable.ic_user, 5), Triple("NEXORA Premium", R.drawable.ic_crown, 6))
    Column(Modifier.width(124.dp).fillMaxHeight().background(PN).verticalScroll(rememberScrollState()).padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        entries.forEach { (l, ic, idx) ->
            val on = tab == idx
            Row(Modifier.fillMaxWidth().clip(CUT).background(if (on) RD else Color.Transparent).clickable { pick(idx) }.padding(10.dp, 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(painterResource(ic), null, tint = if (on) WH else GY, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                T(l, if (on) WH else GY, 11, FontWeight.SemiBold)
            }
        }
        Column(Modifier.fillMaxWidth().panel(RD).clickable { pick(6) }.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(painterResource(R.drawable.ic_crown), null, tint = RD, modifier = Modifier.size(18.dp))
            Text("DESBLOQUEIE TODOS OS RECURSOS", color = WH, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Btn("VER PLANOS", Modifier.fillMaxWidth()) { pick(6) }
        }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(64.dp)); T("v1.0.0", GY, 9)
        }
    }
}

@Composable
fun HomePage(m: Modifier, h: Hist, pg: Map<String, Long>, sorted: List<Node>, active: String?, best: String?, ping: Long, jit: Int, loss: Int,
    prof: Int, st: Int, busy: Boolean, auto: Boolean, a: Act) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("nx", 0) }
    val games = (prefs.getStringSet("games", emptySet()) ?: emptySet()).toList().take(8)
    val (ql, qc) = qual(ping, loss)
    var mt by remember { mutableIntStateOf(0) }
    val p = PROFS[prof]
    val mons = listOf(Triple("PING", h.ping, 200f), Triple("CPU", h.cpu, 100f), Triple("RAM", h.ram, 100f), Triple("TEMP", h.temp, 60f), Triple("BAT", h.batH, 100f), Triple("REDE", h.net, 2000f))
    val units = listOf("ms", "%", "%", " C", "%", " KB/s")
    val cur = mons[mt].second.lastOrNull()?.toInt() ?: 0
    val ram = h.ram.lastOrNull()?.toInt() ?: 0
    Column(m.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().height(176.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(2.3f).fillMaxHeight().panel(RD.copy(alpha = 0.6f)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1.1f)) {
                        T("SEU DISPOSITIVO", GY, 8); T(Build.MODEL, WH, 13, FontWeight.Black); T("Android ${Build.VERSION.RELEASE}", GY, 9)
                        Spacer(Modifier.height(4.dp)); T("Bateria ${h.bat}%", WH, 10)
                        LinearProgressIndicator(progress = { h.bat / 100f }, modifier = Modifier.fillMaxWidth(), color = GN, trackColor = LN)
                        T("Temperatura ${h.tempC} C", WH, 10)
                    }
                    Metric("TELA", "${h.hz.toInt()} Hz", "Atual", GN, emptyList(), 1f, Modifier.weight(0.8f))
                    Metric("PING", if (ping >= 0) "$ping ms" else "--", ql, qc, h.ping, 200f, Modifier.weight(1f))
                    Metric("JITTER", "$jit ms", if (jit < 15) "Bom" else "Alto", if (jit < 15) GN else YL, emptyList(), 1f, Modifier.weight(0.8f))
                    Metric("PERDA", "$loss%", if (loss == 0) "Perfeito" else "Ruim", if (loss == 0) GN else RD, emptyList(), 1f, Modifier.weight(0.8f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Gauge("CPU", h.cpuNow, if (st == 2) "${h.cpuNow}%" else "--", WH)
                    Gauge("RAM", ram, "$ram%", RD)
                    Gauge("REDE", h.netKb / 20, if (h.netKb >= 1000) "%.1fM".format(h.netKb / 1000f) else "${h.netKb}K", GN)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Btn(if (busy) "TRABALHANDO..." else "OTIMIZAR AGORA", Modifier.fillMaxWidth()) { a.optimize() }
                        Row(Modifier.fillMaxWidth().panel(p.c).clickable { a.setProf((prof + 1) % PROFS.size) }.padding(8.dp, 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { T("Perfil atual (toque p/ trocar)", GY, 7); T(p.n, p.c, 10, FontWeight.Black) }
                        }
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight().clip(CUT).background(Brush.linearGradient(listOf(Color(0xFF4A0008), BK))).border(1.dp, RD, CUT).padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween) {
                Row {
                    Text("NEXORA", fontSize = 14.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, color = WH)
                    Text(" GX", fontSize = 14.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, color = RD)
                }
                Text("MAIS DESEMPENHO\nMENOS LAG\nMAIS VITORIAS", color = WH, fontSize = 11.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                Btn("ATIVAR PREMIUM", Modifier.fillMaxWidth()) { a.go(6) }
            }
        }
        Row(Modifier.fillMaxWidth().height(196.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Pane("ROTA DE CONEXAO", Modifier.weight(1.25f).fillMaxHeight()) {
                for (n in sorted.take(5)) {
                    val ms = pg[n.n]; val b = n.n == best
                    Row(Modifier.fillMaxWidth().background(if (n.n == active) RD.copy(alpha = 0.18f) else Color.Transparent).clickable { a.selRoute(n.n) }.padding(4.dp, 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        T(n.n + if (b) " (melhor)" else "", if (b) RD else WH, 10, FontWeight.SemiBold, Modifier.weight(1f))
                        T(if (ms == null) "-" else if (ms < 0) "off" else "$ms ms", if (b) RD else WH, 10, FontWeight.Bold, Modifier.padding(horizontal = 6.dp))
                        Bars(ms ?: -1L, if (b) GN else WH)
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("ATIVAR ROTA", Modifier.weight(1f)) { a.activate() }
                    Btn("TESTAR CONEXAO", Modifier.weight(1f), false) { a.scan() }
                }
            }
            Pane("JOGOS MAIS USADOS", Modifier.weight(1.25f).fillMaxHeight(), "Ver todos >", { a.go(7) }) {
                if (games.isEmpty()) T("Marque seus jogos em Jogos > MARCAR", GY, 10)
                for (row in games.chunked(4)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (g in row) GameMini(g, Modifier.weight(1f), a.play)
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Pane("PERFIS", Modifier.weight(1f).fillMaxHeight(), "Ver todos >", { a.go(5) }) {
                PROFS.forEachIndexed { i, pr ->
                    Column(Modifier.fillMaxWidth().panel(if (i == prof) pr.c else LN).clickable { a.setProf(i) }.padding(6.dp)) {
                        T(pr.n, pr.c, 10, FontWeight.Black); Text(pr.d, color = GY, fontSize = 7.sp, maxLines = 1)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(172.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Pane("MONITOR DE DESEMPENHO", Modifier.weight(1.5f).fillMaxHeight(), "Ver todos >", { a.go(3) }) {
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    mons.forEachIndexed { i, t -> Box(Modifier.clip(CUT).background(if (i == mt) RD else PN).clickable { mt = i }.padding(7.dp, 4.dp)) { T(t.first, WH, 8, FontWeight.Bold) } }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.width(70.dp)) { T(mons[mt].first, GY, 8); T("$cur${units[mt]}", WH, 16, FontWeight.Black) }
                    Spark(mons[mt].second, RD, mons[mt].third, Modifier.weight(1f).height(60.dp))
                }
                T(h.last, GY, 9)
            }
            Pane("LIMPEZA RAPIDA", Modifier.weight(0.9f).fillMaxHeight()) {
                Btn("LIMPAR AGORA", Modifier.fillMaxWidth()) { a.clean() }
                for (r in h.clean.take(3)) { T(r.first, GY, 7); T(r.second, WH, 10, FontWeight.Bold) }
                if (h.clean.isEmpty()) T("Toque para limpar RAM e cache", GY, 9)
            }
            Pane("NEXORA AUTO BOOST", Modifier.weight(1.1f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Detecta e otimiza ao abrir seus jogos.", color = GY, fontSize = 8.sp, modifier = Modifier.weight(1f)); Sw(auto) { a.setAuto(it) }
                }
                for (t in listOf("Perfil do jogo ativado", "Melhor rota selecionada", "Memoria otimizada", "Monitoramento iniciado")) T("v  $t", if (auto) GN else GY, 9)
                Spacer(Modifier.weight(1f))
                Column(Modifier.fillMaxWidth().panel(if (auto) GN else LN).padding(6.dp)) {
                    T(if (auto) "PRONTO PARA USAR" else "AUTO BOOST DESLIGADO", if (auto) GN else GY, 9, FontWeight.Black)
                    Text(if (auto) "Abra um jogo marcado para ativar o boost!" else "Ligue e marque seus jogos.", color = GY, fontSize = 8.sp)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("NEXORA GX  .  PERFORMANCE  .  ESTABILIDADE  .  SEM LIMITES", color = GY, fontSize = 8.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
            Text("JOGUE SEM LAG!", color = RD, fontSize = 12.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        }
    }
}

@Composable
fun MonitorPage(m: Modifier, h: Hist) {
    val cs = listOf(
        Mon("PING", "${h.ping.lastOrNull()?.toInt() ?: 0} ms", h.ping, 200f, RD), Mon("CPU", if (h.cpu.isEmpty()) "--" else "${h.cpuNow}%", h.cpu, 100f, WH),
        Mon("RAM EM USO", "${h.ram.lastOrNull()?.toInt() ?: 0}%", h.ram, 100f, RD), Mon("TEMPERATURA", "${h.tempC} C", h.temp, 60f, WH),
        Mon("REDE", "${h.netKb} KB/s", h.net, 2000f, RD), Mon("BATERIA", "${h.bat}%", h.batH, 100f, WH))
    Column(m, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("MONITOR", color = WH, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(cs) { c ->
                Column(Modifier.panel().padding(12.dp)) {
                    Text(c.t, color = GY, fontSize = 10.sp, letterSpacing = 2.sp)
                    Text(c.v, color = WH, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Spark(c.l, c.c, c.mx, Modifier.fillMaxWidth().height(48.dp))
                }
            }
        }
        Text(h.last, color = GY, fontSize = 11.sp)
    }
}

suspend fun cleanNow(ctx: Context, h: Hist): List<Pair<String, String>> {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    fun avail(): Long { val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); return mi.availMem / 1048576 }
    fun free(): Long = StatFs(Environment.getDataDirectory().path).availableBytes / 1048576
    val r0 = avail(); val f0 = free()
    val p0 = withContext(Dispatchers.IO) { sh("ps -A | wc -l").trim().toIntOrNull() ?: 0 }
    withContext(Dispatchers.IO) { sh("am kill-all; pm trim-caches 999G") }
    delay(1500)
    val r1 = avail(); val f1 = free()
    val p1 = withContext(Dispatchers.IO) { sh("ps -A | wc -l").trim().toIntOrNull() ?: 0 }
    h.last = "Ultima limpeza: RAM livre $r0 MB -> $r1 MB"
    ctx.getSharedPreferences("nx", 0).edit().putString("last", h.last).apply()
    return listOf("RAM LIBERADA" to "${maxOf(0L, r1 - r0)} MB", "PROCESSOS ENCERRADOS" to "${maxOf(0, p0 - p1)}",
        "CACHE E ESPACO" to "$f0 -> $f1 MB", "RAM LIVRE" to "$r1 MB")
}

@Composable
fun CleanPage(m: Modifier, st: Int, h: Hist) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    Column(m, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("LIMPEZA", color = WH, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Btn(if (busy) "LIMPANDO..." else "LIMPAR AGORA", Modifier.fillMaxWidth()) {
            if (busy) return@Btn
            if (st != 2) { msg = "Ative e autorize o Shizuku"; return@Btn }
            scope.launch { busy = true; msg = "Limpando..."; h.clean = cleanNow(ctx, h); msg = "Concluido"; busy = false }
        }
        Text(msg, color = GY, fontSize = 12.sp)
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(h.clean) { r -> Stat(r.first, r.second, Modifier.fillMaxWidth()) }
        }
    }
}

@Composable
fun PerfisPage(m: Modifier, cur: Int, pick: (Int) -> Unit) {
    Column(m, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("PERFIS", color = WH, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(PROFS.indices.toList()) { i ->
                val p = PROFS[i]
                Column(Modifier.fillMaxWidth().panel(if (i == cur) p.c else LN).clickable { pick(i) }.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(p.n, color = p.c, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Text(p.d, color = GY, fontSize = 11.sp)
                    if (i == cur) Text("ATIVO", color = WH, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }
            }
        }
        Text("Perfil personalizado: em breve.", color = GY, fontSize = 11.sp)
    }
}

@Composable
fun PremiumPage(m: Modifier) {
    Column(m.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row {
            Text("NEXORA ", fontSize = 22.sp, fontWeight = FontWeight.Black, color = WH, letterSpacing = 3.sp)
            Text("PREMIUM", fontSize = 22.sp, fontWeight = FontWeight.Black, color = RD, letterSpacing = 3.sp)
        }
        for (t in listOf("Todos os perfis e ajuste por jogo", "Auto Boost ao abrir o jogo", "Rotas e monitoramento em tempo real", "Historico de sessoes", "Atualizacoes", "Suporte")) {
            Row(Modifier.fillMaxWidth().panel().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(t, color = WH, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("INCLUIDO", color = RD, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
        Text("A cobranca e o bloqueio por licenca serao ligados na versao de lancamento.", color = GY, fontSize = 11.sp)
    }
}

@Composable
fun GamePage(m: Modifier, st: Int, prof: Int, startMode: Int = 0) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("nx", 0) }
    val frozen = remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("frozen", emptySet()) ?: emptySet()) } }
    val games = remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("games", emptySet()) ?: emptySet()) } }
    val gpm = remember { mutableStateMapOf<String, Int>() }
    val picked = remember { mutableStateListOf<String>() }
    var mode by remember { mutableIntStateOf(startMode) }
    var hz by remember { mutableIntStateOf(0) }
    var auto by remember { mutableStateOf(prefs.getBoolean("auto", false)) }
    var log by remember { mutableStateOf("> escolha um jogo") }
    val apps by produceState(emptyList<AppI>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).mapNotNull { r ->
                val p = r.activityInfo.packageName
                if (p == ctx.packageName) null else try {
                    AppI(r.loadLabel(pm).toString(), p, r.loadIcon(pm).toBitmap(96, 96).asImageBitmap(), (r.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
                } catch (e: Throwable) { null }
            }.distinctBy { it.p }.sortedBy { it.n.lowercase() }
        }
    }
    fun saveF() { prefs.edit().putStringSet("frozen", frozen.toSet()).apply() }
    fun saveG() { prefs.edit().putStringSet("games", games.toSet()).apply() }
    fun gp(p: String): Int = gpm[p] ?: prefs.getInt("gp_$p", prof)
    fun exec(cmd: String, ok: String, after: () -> Unit = {}) {
        if (st != 2) { log = "> ative e autorize o Shizuku"; return }
        scope.launch { log = "> executando..."; val r = withContext(Dispatchers.IO) { sh(cmd) }; log = "> $ok ($r)"; after() }
    }
    fun hzCmd(h: Int) = if (h == 0) "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        else "settings put system min_refresh_rate $h; settings put system peak_refresh_rate $h"
    fun play(a: AppI, boost: Boolean) {
        scope.launch {
            if (boost && st == 2) { val pr = PROFS[gp(a.p)]; log = "> ${a.n}: perfil ${pr.n}"; withContext(Dispatchers.IO) { applyProfile(pr, a.p) } }
            else if (hz > 0 && st == 2) withContext(Dispatchers.IO) { sh(hzCmd(hz)) }
            ctx.packageManager.getLaunchIntentForPackage(a.p)?.let { ctx.startActivity(it) }
        }
    }
    val list = when (mode) { 0 -> apps.filter { it.p in games }; 3 -> apps.filter { !it.sys && it.p !in frozen }; else -> apps }
    Row(m, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(1.5f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip("JOGOS", mode == 0) { mode = 0 }; Chip("APPS", mode == 1) { mode = 1 }
                Chip("MARCAR", mode == 2) { mode = 2 }; Chip("CONGELAR", mode == 3) { mode = 3 }
            }
            Text(listOf("seus jogos: otimiza e abre", "toque para abrir o app", "toque para marcar seus jogos", "toque para escolher o que congelar")[mode], color = GY, fontSize = 11.sp)
            if (apps.isEmpty()) Text("carregando apps...", color = GY, fontSize = 12.sp)
            if (mode == 0) {
                if (list.isEmpty() && apps.isNotEmpty()) Text("Nenhum jogo ainda. Use MARCAR para escolher seus jogos.", color = GY, fontSize = 12.sp)
                LazyVerticalGrid(GridCells.Adaptive(160.dp), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list) { a ->
                        Column(Modifier.panel().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Image(a.ic, null, Modifier.size(48.dp))
                            Text(a.n, color = WH, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Chip("PERFIL: " + PROFS[gp(a.p)].n.substringBefore(' '), false) {
                                val n = (gp(a.p) + 1) % PROFS.size; gpm[a.p] = n; prefs.edit().putInt("gp_${a.p}", n).apply()
                            }
                            Row(Modifier.fillMaxWidth().clip(CUT).background(RD).clickable { play(a, true) }.padding(vertical = 9.dp), horizontalArrangement = Arrangement.Center) {
                                Text("OTIMIZAR + JOGAR", color = WH, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            } else LazyVerticalGrid(GridCells.Adaptive(76.dp), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list) { a ->
                    AppCell(a, (mode == 2 && a.p in games) || (mode == 3 && a.p in picked)) {
                        when (mode) {
                            1 -> play(a, false)
                            2 -> { if (a.p in games) games.remove(a.p) else games.add(a.p); saveG() }
                            else -> { if (a.p in picked) picked.remove(a.p) else picked.add(a.p) }
                        }
                    }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Label("AUTO BOOST")
            Chip(if (auto) "AUTO BOOST: LIGADO" else "AUTO BOOST: DESLIGADO", auto) {
                auto = !auto; prefs.edit().putBoolean("auto", auto).apply()
                if (auto) { ContextCompat.startForegroundService(ctx, Intent(ctx, RouteService::class.java)); log = "> ligado. conceda o acesso de uso e marque seus jogos" }
            }
            Chip("ACESSO DE USO", false) { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            Label("TAXA DE ATUALIZACAO")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (h in listOf(0, 60, 90, 120, 144)) Chip(if (h == 0) "AUTO" else "$h", hz == h) { hz = h; exec(hzCmd(h), if (h == 0) "Hz automatico" else "$h Hz aplicado") }
            }
            Label("CONGELAR APPS")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("CONGELAR (${picked.size})", true) {
                    if (picked.isEmpty()) log = "> escolha apps na aba CONGELAR" else {
                        val ps = picked.toList()
                        exec(ps.joinToString("; ") { "pm disable-user --user 0 $it" }, "${ps.size} app(s) congelado(s)") { frozen.addAll(ps); picked.clear(); saveF() }
                    }
                }
                Chip("DESCONGELAR TUDO", false) {
                    if (frozen.isEmpty()) log = "> nada congelado" else {
                        val ps = frozen.toList()
                        exec(ps.joinToString("; ") { "pm enable $it" }, "apps descongelados") { frozen.clear(); saveF() }
                    }
                }
            }
            if (frozen.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(frozen.toList()) { p ->
                        val ic = remember(p) { iconOf(ctx, p) }
                        Column(Modifier.panel(RD).clickable { exec("pm enable $p", "descongelado") { frozen.remove(p); saveF() } }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            if (ic != null) Image(ic, null, Modifier.size(36.dp)) else Box(Modifier.size(36.dp).background(LN))
                            Text(p.substringAfterLast('.').take(10), color = WH, fontSize = 8.sp, maxLines = 1)
                        }
                    }
                }
            }
            Column(Modifier.fillMaxWidth().panel().padding(12.dp)) {
                Text("CONSOLE", color = GY, fontSize = 10.sp, letterSpacing = 3.sp)
                Text(log, color = WH, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
    }
}
