package com.nexora.gx

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Prof(val n: String, val c: Color, val hz: Int, val anim: String, val kill: Boolean, val lp: Int, val mode: String, val d: String)
val PROFS = listOf(
    Prof("ULTRA PERFORMANCE", RD, 120, "0.5", true, 0, "performance", "120 Hz, animacoes 0.5x, limpa RAM, modo desempenho"),
    Prof("GAMING", Color(0xFFFF8A3D), 90, "0.5", true, 0, "performance", "90 Hz, animacoes 0.5x, limpa RAM, modo desempenho"),
    Prof("EQUILIBRADO", GN, 0, "1.0", false, 0, "standard", "Hz automatico, animacoes normais"),
    Prof("BATERIA", Color(0xFF4DA3FF), 60, "1.0", false, 1, "battery", "60 Hz, economia de bateria ligada"))

fun applyProfile(p: Prof, pkg: String?): String {
    val c = ArrayList<String>()
    c.add(if (p.hz == 0) "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        else "settings put system min_refresh_rate ${p.hz}; settings put system peak_refresh_rate ${p.hz}")
    c.add("settings put global window_animation_scale ${p.anim}; settings put global transition_animation_scale ${p.anim}; settings put global animator_duration_scale ${p.anim}")
    c.add("settings put global low_power ${p.lp}")
    if (p.kill) c.add("am kill-all")
    if (pkg != null) c.add("cmd game mode ${p.mode} $pkg")
    return sh(c.joinToString("; "))
}

fun <T> MutableList<T>.cap(v: T) { add(v); if (size > 60) removeAt(0) }

class Hist {
    val ram = mutableStateListOf<Float>(); val cpu = mutableStateListOf<Float>(); val temp = mutableStateListOf<Float>()
    val ping = mutableStateListOf<Float>(); val net = mutableStateListOf<Float>(); val batH = mutableStateListOf<Float>()
    var availMb by mutableStateOf(0L); var tempC by mutableStateOf(0f); var bat by mutableStateOf(0)
    var hz by mutableStateOf(0f); var cpuNow by mutableStateOf(0); var netKb by mutableStateOf(0)
    var last by mutableStateOf("")
}

class AppI(val n: String, val p: String, val ic: ImageBitmap, val sys: Boolean)
class Mon(val t: String, val v: String, val l: List<Float>, val mx: Float, val c: Color)

fun iconOf(ctx: Context, p: String): ImageBitmap? = try { ctx.packageManager.getApplicationIcon(p).toBitmap(96, 96).asImageBitmap() } catch (e: Throwable) { null }

@Composable
fun Spark(v: List<Float>, c: Color, mx: Float, m: Modifier) {
    Canvas(m) {
        if (v.size < 2) return@Canvas
        val dx = size.width / 59f; val p = Path()
        v.forEachIndexed { i, y ->
            val py = size.height - (y / mx).coerceIn(0f, 1f) * size.height
            if (i == 0) p.moveTo(0f, py) else p.lineTo(i * dx, py)
        }
        drawPath(p, c, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
    }
}

@Composable
fun AppCell(a: AppI, on: Boolean, click: () -> Unit) {
    Column(Modifier.clip(CUT).background(if (on) RD.copy(alpha = 0.25f) else PN).border(1.dp, if (on) RD else LN, CUT).clickable(onClick = click).padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Image(a.ic, null, Modifier.size(44.dp))
        Text(a.n, color = WH, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
fun NavRail(tab: Int, pick: (Int) -> Unit) {
    val items = listOf("INICIO" to R.drawable.ic_display, "ROTAS" to R.drawable.ic_boost, "GAME" to R.drawable.ic_game, "MONITOR" to R.drawable.ic_ram,
        "LIMPEZA" to R.drawable.ic_clean, "PERFIS" to R.drawable.ic_shield, "PREMIUM" to R.drawable.ic_sun)
    Column(Modifier.width(84.dp).fillMaxHeight().background(PN).verticalScroll(rememberScrollState()).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(60.dp))
        items.forEachIndexed { i, t ->
            Column(Modifier.fillMaxWidth().background(if (tab == i) RD.copy(alpha = 0.2f) else Color.Transparent).clickable { pick(i) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(painterResource(t.second), null, tint = if (tab == i) RD else GY, modifier = Modifier.size(20.dp))
                Text(t.first, color = if (tab == i) WH else GY, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun HomePage(m: Modifier, h: Hist, ping: Long, jit: Int, loss: Int, prof: Prof, busy: Boolean, st: Int, log: String, go: () -> Unit) {
    Row(m, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Column(Modifier.weight(0.9f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row {
                Text("NEXORA", fontSize = 24.sp, fontWeight = FontWeight.Black, color = WH, letterSpacing = 3.sp)
                Text(" GX", fontSize = 24.sp, fontWeight = FontWeight.Black, color = RD, letterSpacing = 3.sp)
            }
            Column(Modifier.fillMaxWidth().panel(prof.c).padding(14.dp)) {
                Text("PERFIL ATUAL", color = GY, fontSize = 10.sp, letterSpacing = 3.sp)
                Text(prof.n, color = prof.c, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text(prof.d, color = GY, fontSize = 11.sp)
            }
            Row(Modifier.fillMaxWidth().height(60.dp).clip(CUT).background(RD).clickable(onClick = go), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text(if (busy) "OTIMIZANDO..." else "OTIMIZAR AGORA", color = WH, fontWeight = FontWeight.Black, fontSize = 16.sp, letterSpacing = 3.sp)
            }
            Text(if (st == 2) "Shizuku ativo" else "Ative o Shizuku para otimizar", color = if (st == 2) GN else YL, fontSize = 12.sp)
            Column(Modifier.fillMaxWidth().panel().padding(12.dp)) {
                Text("CONSOLE", color = GY, fontSize = 10.sp, letterSpacing = 3.sp)
                Text(log, color = WH, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
        Column(Modifier.weight(1.1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("PING", if (ping >= 0) "$ping ms" else "--", Modifier.weight(1f)); Stat("JITTER", "$jit ms", Modifier.weight(1f)); Stat("PERDA", "$loss%", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("TEMP", "${h.tempC} C", Modifier.weight(1f)); Stat("RAM LIVRE", "${h.availMb} MB", Modifier.weight(1f)); Stat("CPU", if (st == 2) "${h.cpuNow}%" else "--", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("BATERIA", "${h.bat}%", Modifier.weight(1f)); Stat("TELA", "${h.hz.toInt()} Hz", Modifier.weight(1f)); Stat("REDE", "${h.netKb} KB/s", Modifier.weight(1f))
            }
            Text(h.last, color = GY, fontSize = 11.sp)
        }
    }
}

@Composable
fun MonitorPage(m: Modifier, h: Hist) {
    val cs = listOf(
        Mon("PING", "${h.ping.lastOrNull()?.toInt() ?: 0} ms", h.ping, 200f, RD), Mon("CPU", if (h.cpu.isEmpty()) "--" else "${h.cpuNow}%", h.cpu, 100f, WH),
        Mon("RAM EM USO", "${h.ram.lastOrNull()?.toInt() ?: 0}%", h.ram, 100f, RD), Mon("TEMPERATURA", "${h.tempC} C", h.temp, 60f, WH),
        Mon("REDE", "${h.netKb} KB/s", h.net, 2000f, RD), Mon("BATERIA", "${h.bat}%", h.batH, 100f, WH))
    Column(m, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("MONITOR", color = WH, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(cs) { c ->
                Column(Modifier.panel().padding(12.dp)) {
                    Text(c.t, color = GY, fontSize = 10.sp, letterSpacing = 2.sp)
                    Text(c.v, color = WH, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Spark(c.l, c.c, c.mx, Modifier.fillMaxWidth().height(48.dp))
                }
            }
        }
        Text(h.last, color = GY, fontSize = 11.sp)
    }
}

@Composable
fun CleanPage(m: Modifier, st: Int, h: Hist) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var res by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var msg by remember { mutableStateOf("") }
    fun go() {
        if (busy) return
        if (st != 2) { msg = "Ative e autorize o Shizuku"; return }
        scope.launch {
            busy = true; msg = "Limpando..."
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            fun avail(): Long { val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); return mi.availMem / 1048576 }
            fun free(): Long = StatFs(Environment.getDataDirectory().path).availableBytes / 1048576
            val r0 = avail(); val f0 = free()
            val p0 = withContext(Dispatchers.IO) { sh("ps -A | wc -l").trim().toIntOrNull() ?: 0 }
            withContext(Dispatchers.IO) { sh("am kill-all; pm trim-caches 999G") }
            delay(1500)
            val r1 = avail(); val f1 = free()
            val p1 = withContext(Dispatchers.IO) { sh("ps -A | wc -l").trim().toIntOrNull() ?: 0 }
            res = listOf("RAM LIBERADA" to "${maxOf(0L, r1 - r0)} MB", "PROCESSOS ENCERRADOS" to "${maxOf(0, p0 - p1)}",
                "CACHE E ESPACO" to "$f0 -> $f1 MB", "RAM LIVRE" to "$r1 MB")
            h.last = "Ultima limpeza: RAM livre $r0 MB -> $r1 MB"
            ctx.getSharedPreferences("nx", 0).edit().putString("last", h.last).apply()
            msg = "Concluido"; busy = false
        }
    }
    Column(m, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("LIMPEZA", color = WH, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Row(Modifier.fillMaxWidth().height(60.dp).clip(CUT).background(RD).clickable { go() }, horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text(if (busy) "LIMPANDO..." else "LIMPAR AGORA", color = WH, fontWeight = FontWeight.Black, fontSize = 16.sp, letterSpacing = 3.sp)
        }
        Text(msg, color = GY, fontSize = 12.sp)
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(res) { r -> Stat(r.first, r.second, Modifier.fillMaxWidth()) }
        }
    }
}

@Composable
fun PerfisPage(m: Modifier, cur: Int, pick: (Int) -> Unit) {
    Column(m, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("PERFIS", color = WH, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(PROFS.indices.toList()) { i ->
                val p = PROFS[i]
                Column(Modifier.fillMaxWidth().panel(if (i == cur) p.c else LN).clickable { pick(i) }.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(p.n, color = p.c, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Text(p.d, color = GY, fontSize = 11.sp)
                    if (i == cur) Text("ATIVO", color = WH, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }
            }
        }
        Text("Perfil personalizado: em breve.", color = GY, fontSize = 11.sp)
    }
}

@Composable
fun PremiumPage(m: Modifier) {
    Column(m.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row {
            Text("NEXORA ", fontSize = 22.sp, fontWeight = FontWeight.Black, color = WH, letterSpacing = 3.sp)
            Text("PREMIUM", fontSize = 22.sp, fontWeight = FontWeight.Black, color = RD, letterSpacing = 3.sp)
        }
        for (t in listOf("Todos os perfis e ajuste por jogo", "Auto Boost ao abrir o jogo", "Rotas e monitoramento em tempo real", "Historico de sessoes", "Atualizacoes", "Suporte")) {
            Row(Modifier.fillMaxWidth().panel().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(t, color = WH, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("INCLUIDO", color = RD, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
        Text("A cobranca e o bloqueio por licenca serao ligados na versao de lancamento.", color = GY, fontSize = 11.sp)
    }
}

@Composable
fun GamePage(m: Modifier, st: Int, prof: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("nx", 0) }
    val frozen = remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("frozen", emptySet()) ?: emptySet()) } }
    val games = remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("games", emptySet()) ?: emptySet()) } }
    val gpm = remember { mutableStateMapOf<String, Int>() }
    val picked = remember { mutableStateListOf<String>() }
    var mode by remember { mutableIntStateOf(0) }
    var hz by remember { mutableIntStateOf(0) }
    var auto by remember { mutableStateOf(prefs.getBoolean("auto", false)) }
    var log by remember { mutableStateOf("> escolha um jogo") }
    val apps by produceState(emptyList<AppI>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).mapNotNull { r ->
                val p = r.activityInfo.packageName
                if (p == ctx.packageName) null else try {
                    AppI(r.loadLabel(pm).toString(), p, r.loadIcon(pm).toBitmap(96, 96).asImageBitmap(), (r.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
                } catch (e: Throwable) { null }
            }.distinctBy { it.p }.sortedBy { it.n.lowercase() }
        }
    }
    fun saveF() { prefs.edit().putStringSet("frozen", frozen.toSet()).apply() }
    fun saveG() { prefs.edit().putStringSet("games", games.toSet()).apply() }
    fun gp(p: String): Int = gpm[p] ?: prefs.getInt("gp_$p", prof)
    fun exec(cmd: String, ok: String, after: () -> Unit = {}) {
        if (st != 2) { log = "> ative e autorize o Shizuku"; return }
        scope.launch { log = "> executando..."; val r = withContext(Dispatchers.IO) { sh(cmd) }; log = "> $ok ($r)"; after() }
    }
    fun hzCmd(h: Int) = if (h == 0) "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        else "settings put system min_refresh_rate $h; settings put system peak_refresh_rate $h"
    fun play(a: AppI, boost: Boolean) {
        scope.launch {
            if (boost && st == 2) { val pr = PROFS[gp(a.p)]; log = "> ${a.n}: perfil ${pr.n}"; withContext(Dispatchers.IO) { applyProfile(pr, a.p) } }
            else if (hz > 0 && st == 2) withContext(Dispatchers.IO) { sh(hzCmd(hz)) }
            ctx.packageManager.getLaunchIntentForPackage(a.p)?.let { ctx.startActivity(it) }
        }
    }
    val list = when (mode) { 0 -> apps.filter { it.p in games }; 3 -> apps.filter { !it.sys && it.p !in frozen }; else -> apps }
    Row(m, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(1.5f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip("JOGOS", mode == 0) { mode = 0 }; Chip("APPS", mode == 1) { mode = 1 }
                Chip("MARCAR", mode == 2) { mode = 2 }; Chip("CONGELAR", mode == 3) { mode = 3 }
            }
            Text(listOf("seus jogos: otimiza e abre", "toque para abrir o app", "toque para marcar seus jogos", "toque para escolher o que congelar")[mode], color = GY, fontSize = 11.sp)
            if (apps.isEmpty()) Text("carregando apps...", color = GY, fontSize = 12.sp)
            if (mode == 0) {
                if (list.isEmpty() && apps.isNotEmpty()) Text("Nenhum jogo ainda. Use MARCAR para escolher seus jogos.", color = GY, fontSize = 12.sp)
                LazyVerticalGrid(GridCells.Adaptive(160.dp), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list) { a ->
                        Column(Modifier.panel().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Image(a.ic, null, Modifier.size(48.dp))
                            Text(a.n, color = WH, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Chip("PERFIL: " + PROFS[gp(a.p)].n.substringBefore(' '), false) {
                                val n = (gp(a.p) + 1) % PROFS.size; gpm[a.p] = n; prefs.edit().putInt("gp_${a.p}", n).apply()
                            }
                            Row(Modifier.fillMaxWidth().clip(CUT).background(RD).clickable { play(a, true) }.padding(vertical = 9.dp), horizontalArrangement = Arrangement.Center) {
                                Text("OTIMIZAR + JOGAR", color = WH, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            } else LazyVerticalGrid(GridCells.Adaptive(76.dp), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list) { a ->
                    AppCell(a, (mode == 2 && a.p in games) || (mode == 3 && a.p in picked)) {
                        when (mode) {
                            1 -> play(a, false)
                            2 -> { if (a.p in games) games.remove(a.p) else games.add(a.p); saveG() }
                            else -> { if (a.p in picked) picked.remove(a.p) else picked.add(a.p) }
                        }
                    }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Label("AUTO BOOST")
            Chip(if (auto) "AUTO BOOST: LIGADO" else "AUTO BOOST: DESLIGADO", auto) {
                auto = !auto; prefs.edit().putBoolean("auto", auto).apply()
                if (auto) { ContextCompat.startForegroundService(ctx, Intent(ctx, RouteService::class.java)); log = "> ligado. conceda o acesso de uso e marque seus jogos" }
            }
            Chip("ACESSO DE USO", false) { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            Label("TAXA DE ATUALIZACAO")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (h in listOf(0, 60, 90, 120, 144)) Chip(if (h == 0) "AUTO" else "$h", hz == h) { hz = h; exec(hzCmd(h), if (h == 0) "Hz automatico" else "$h Hz aplicado") }
            }
            Label("CONGELAR APPS")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("CONGELAR (${picked.size})", true) {
                    if (picked.isEmpty()) log = "> escolha apps na aba CONGELAR" else {
                        val ps = picked.toList()
                        exec(ps.joinToString("; ") { "pm disable-user --user 0 $it" }, "${ps.size} app(s) congelado(s)") { frozen.addAll(ps); picked.clear(); saveF() }
                    }
                }
                Chip("DESCONGELAR TUDO", false) {
                    if (frozen.isEmpty()) log = "> nada congelado" else {
                        val ps = frozen.toList()
                        exec(ps.joinToString("; ") { "pm enable $it" }, "apps descongelados") { frozen.clear(); saveF() }
                    }
                }
            }
            if (frozen.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(frozen.toList()) { p ->
                        val ic = remember(p) { iconOf(ctx, p) }
                        Column(Modifier.panel(RD).clickable { exec("pm enable $p", "descongelado") { frozen.remove(p); saveF() } }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            if (ic != null) Image(ic, null, Modifier.size(36.dp)) else Box(Modifier.size(36.dp).background(LN))
                            Text(p.substringAfterLast('.').take(10), color = WH, fontSize = 8.sp, maxLines = 1)
                        }
                    }
                }
            }
            Column(Modifier.fillMaxWidth().panel().padding(12.dp)) {
                Text("CONSOLE", color = GY, fontSize = 10.sp, letterSpacing = 3.sp)
                Text(log, color = WH, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
    }
}
