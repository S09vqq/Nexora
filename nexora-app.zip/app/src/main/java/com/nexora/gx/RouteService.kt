package com.nexora.gx

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.InetAddress

class RouteService : Service() {
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("nx", "Rota ativa", NotificationManager.IMPORTANCE_LOW))
        fun note(t: String) = NotificationCompat.Builder(this, "nx").setSmallIcon(R.drawable.ic_boost)
            .setContentTitle("Nexora GX").setContentText(t).setOngoing(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        startForeground(1, note("Procurando a melhor rota..."))
        scope.coroutineContext.cancelChildren()
        scope.launch {
            var best: Node? = null; var t = 0
            while (isActive) {
                if (best == null || t % 6 == 0) {
                    best = NODES.map { n -> n to (try { tcpMs(InetAddress.getByName(n.h), 443) } catch (e: Throwable) { -1L }) }
                        .filter { it.second >= 0 }.minByOrNull { it.second }?.first
                }
                val b = best
                val ms = if (b == null) -1L else try { tcpMs(InetAddress.getByName(b.h), 443) } catch (e: Throwable) { -1L }
                nm.notify(1, note(if (b == null) "Sem rede" else "Rota ${b.n}: " + (if (ms >= 0) "$ms ms" else "sem resposta")))
                delay(5000); t++
            }
        }
        return START_STICKY
    }

    override fun onDestroy() { running = false; job.cancel(); super.onDestroy() }
    companion object { @Volatile var running = false }
}
