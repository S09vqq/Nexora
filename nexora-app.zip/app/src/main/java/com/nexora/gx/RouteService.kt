package com.nexora.gx

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.InetAddress

class RouteService : Service() {
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)
    override fun onBind(i: Intent?): IBinder? = null

    private fun fgPkg(): String? = try {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - 15000, now); val e = UsageEvents.Event(); var p: String? = null
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) p = e.packageName }
        p
    } catch (e: Throwable) { null }

    private fun labelOf(p: String): String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString() } catch (e: Throwable) { p }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("nx", "Rota ativa", NotificationManager.IMPORTANCE_LOW))
        fun note(t: String) = NotificationCompat.Builder(this, "nx").setSmallIcon(R.drawable.ic_boost)
            .setContentTitle("Nexora GX").setContentText(t).setOngoing(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        startForeground(1, note("Procurando a melhor rota..."))
        scope.coroutineContext.cancelChildren()
        val prefs = getSharedPreferences("nx", 0)
        scope.launch {
            var best: Node? = null; var t = 0; var ms = -1L
            var lastFg: String? = null; var boosted: String? = null; var prof = PROFS[2]
            while (isActive) {
                if (best == null || t % 15 == 0) {
                    best = NODES.map { n -> n to (try { tcpMs(InetAddress.getByName(n.h), 443) } catch (e: Throwable) { -1L }) }
                        .filter { it.second >= 0 }.minByOrNull { it.second }?.first
                }
                if (prefs.getBoolean("auto", false) && stNow() == 2) {
                    val p = fgPkg()
                    if (p != null && p != lastFg) {
                        lastFg = p
                        val games = prefs.getStringSet("games", emptySet()) ?: emptySet()
                        if (p in games) {
                            boosted = p; prof = PROFS[prefs.getInt("gp_$p", prefs.getInt("prof", 2))]
                            note("Aplicando perfil ${prof.n}..."); applyProfile(prof, p)
                        } else if (boosted != null) {
                            boosted = null; applyProfile(PROFS[prefs.getInt("prof", 2)], null)
                        }
                    }
                }
                val b = best
                if (b != null && t % 3 == 0) ms = try { tcpMs(InetAddress.getByName(b.h), 443) } catch (e: Throwable) { -1L }
                val route = if (b == null) "sem rede" else "rota ${b.n} " + (if (ms >= 0) "$ms ms" else "sem resposta")
                val text = if (boosted != null) "BOOST ATIVO: ${labelOf(boosted)} | ${prof.n} | $route" else route
                nm.notify(1, note(text))
                delay(2000); t++
            }
        }
        return START_STICKY
    }

    override fun onDestroy() { running = false; job.cancel(); super.onDestroy() }
    companion object { @Volatile var running = false }
}
